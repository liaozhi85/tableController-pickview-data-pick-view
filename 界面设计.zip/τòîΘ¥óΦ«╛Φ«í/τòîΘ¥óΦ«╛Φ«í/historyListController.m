//
//  twoController.m
//  界面设计
//
//  Created by liaozhi on 16/6/13.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import "historyListController.h"
#import "operateListArray.h"
#import "detailHistory.h"
@interface historyListController ()
@property (nonatomic,strong)NSMutableArray<NSMutableArray *> *list;
@property (nonatomic,strong)operateListArray *operate;
@property (nonatomic,strong)IBOutlet UITableView *table;
@end
@implementation historyListController
- (operateListArray *)operate {
    if (!_operate) {
        _operate = [[operateListArray alloc] init];
    }
    return _operate;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.operate creatFile];
    [self.operate HcreatFile];
    self.list = [self.operate readAllList];
    self.table.delegate = self;
    self.table.dataSource = self;
//    self.table.rowHeight = self.view.frame.size.height/10.0;
}
#pragma mark -UITableViewDataSource的实现
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.list.count+1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"info";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    if (indexPath.row == 0) {
        
    }else{
        if ([self.list[indexPath.row-1][1] isEqualToString:@"女"]) {
            cell.imageView.image = [UIImage imageNamed:@"women.png"];
        }else{
            cell.imageView.image = [UIImage imageNamed:@"man.png"];
        }
        NSString *birthday = self.list[indexPath.row-1][2];
        int age = (int)[self getHowOld:birthday];
        NSString *text = [NSString stringWithFormat:@"%@",self.list[indexPath.row-1][0]];
        cell.textLabel.text = text;
        
        NSString *detail = [NSString stringWithFormat:@"%@cm  %@kg  %i岁",self.list[indexPath.row-1][3],self.list[indexPath.row-1][4],age];
        cell.detailTextLabel.text = detail;
        
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.operate HdeleteUserAllInfo:self.list[indexPath.row-1]];
        [self.operate deleteUserInfo:self.list[indexPath.row-1]];
        [self.list removeObjectAtIndex:indexPath.row-1];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @"删除";
}

#pragma mark -UITableViewDelegate的实现
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return UITableViewCellEditingStyleNone;
    }else{
        return UITableViewCellEditingStyleDelete;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return 0;
    }else{
        return self.view.frame.size.height/10.0;
    }
}
//点击查看详情记录
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES]; 
    [self.operate setUserName:self.list[indexPath.row-1][0]];
    detailHistory *detail = [self.storyboard instantiateViewControllerWithIdentifier:@"detailHistory"];
    [self.navigationController pushViewController:detail animated:YES];
}


#pragma mark -计算年龄
- (NSInteger)getHowOld:(NSString *)text {
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    NSDate *today = [NSDate date];
    NSDate *birthday = [format dateFromString:text];
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSUInteger unitFlags = NSCalendarUnitYear;
    NSDateComponents *components = [gregorian components:unitFlags fromDate:birthday toDate:today options:0];
    NSInteger age = 0;
    switch (unitFlags) {
        case NSCalendarUnitYear:
            age = [components year];
            break;
        case NSCalendarUnitMonth:
            age = [components month];
            break;
        case NSCalendarUnitDay:
            age = [components day];
            break;
            
    }
    return age;
    
    
}
@end
