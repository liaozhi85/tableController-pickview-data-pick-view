//
//  operateListArray.h
//  界面设计
//
//  Created by liaozhi on 16/6/15.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface operateListArray : NSObject
//获取用户名
- (void)setUserName:(NSString *)name;
- (NSString *)getUserName;

//用户信息文件的操作
- (void)creatFile;
- (NSMutableArray *)readAllList;
- (void)addUseInfo:(NSMutableArray *)userInfo;
- (BOOL)compareUserInfo:(NSMutableArray *)userInfo;
- (void)deleteUserInfo:(NSMutableArray *)userInfo;
//历史记录文件的操作
- (void)HcreatFile;
- (NSMutableArray *)HreadAllList;
- (void)HaddUseInfo:(NSMutableArray *)record;
- (NSMutableArray *)HselectUserInfo:(NSString *)userName;
- (BOOL)HcompareUserInfo:(NSMutableArray *)record;
- (void)HdeleteUserAllInfo:(NSMutableArray *)record;
- (void)HdeleteUserOneInfo:(NSMutableArray *)record numberOfRow:(NSInteger)row;
@end
