//
//  oneController.m
//  界面设计
//
//  Created by liaozhi on 16/6/13.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import "registerController.h"
#import "operateListArray.h"
#import "userListController.h"
@interface registerController ()
@property (nonatomic,strong)NSArray *list;
@property (nonatomic,strong)NSNumber *gender;
@property (nonatomic,strong)operateListArray *operate;
@end
@implementation registerController
- (operateListArray *)operate {
    if (!_operate) {
        _operate = [[operateListArray alloc] init];
    }
    return _operate;
}
- (NSArray *)list {
    if (!_list) {
        _list = @[@"姓名",@"性别",@"出生日期",@"身高",@"体重"];
    }
    return _list;
}
- (NSMutableArray *)list2 {
    if (!_list2) {
        _list2 = [[NSMutableArray alloc] initWithObjects:@"填写姓名",@"填写性别",@"填写生日",@"填写身高",@"填写体重", nil];
    }
    return _list2;
}
- (NSNumber *)gender {
    if (!_gender) {
        _gender = [NSNumber numberWithInt:0];
    }
    return _gender;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    [btn setTitle:@"保存信息" forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:1];
    btn.layer.cornerRadius = 10.0;
    btn.frame = CGRectMake(0, 0, 100, 80);
    [btn addTarget:self action:@selector(storeInfo) forControlEvents:UIControlEventTouchUpInside];
    self.table.dataSource = self;
    self.table.delegate = self;
    self.table.rowHeight = self.view.frame.size.height/7.0;
    self.table.tableFooterView = btn;
}
#pragma -mark 判断名字是否为空
- (BOOL)isNameEmpty:(NSString *)name {
    if (!name) {
        return YES;
    }else{
        NSCharacterSet *set = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        NSString *string = [name stringByTrimmingCharactersInSet:set];
        if (string.length == 0) {
            return YES;
        }else{
            return NO;
        }
    }
}
#pragma -mark 保存信息
- (void)storeInfo {
    if ([self.list2[0] isEqualToString:@"填写姓名"] || [self.list2[1] isEqualToString:@"填写性别"] || [self.list2[2] isEqualToString:@"填写生日"] || [self.list2[3] isEqualToString:@"填写身高"] || [self.list2[4] isEqualToString:@"填写体重"]) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"请填写完整信息" message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cert = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:cert];
        [self presentViewController:alertController animated:YES completion:nil];
    }else{
        if ([self.operate compareUserInfo:self.list2]) {
            userListController *one = [self.storyboard instantiateViewControllerWithIdentifier:@"userListController"];
            [self.navigationController pushViewController:one animated:YES];
        }else{
            [self.operate addUseInfo:self.list2];
            userListController *one = [self.storyboard instantiateViewControllerWithIdentifier:@"userListController"];
            [self.navigationController pushViewController:one animated:YES];
        }
        
        
    }
}
#pragma -mark UITableViewDataSource的实现
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;//返回多少组数据
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.list.count;//每组有多少行
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    cell.textLabel.text = self.list[indexPath.row];
    cell.detailTextLabel.text = self.list2[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    return cell;//每行对应一个cell显示
}
#pragma -mark UIPickerViewDataSource的实现
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return 2;
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if (row == 0) {
        return @"女";
    }else{
        return @"男";
    }
}
#pragma -mark UIPickerViewDelegate的实现
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (row == 0) {
        self.gender = [NSNumber numberWithInteger:0];
    }else{
        self.gender = [NSNumber numberWithInteger:1];
    }
}
#pragma -mark UITableViewDelegate的实现
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 0) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:self.list[indexPath.row] message:nil preferredStyle:UIAlertControllerStyleAlert];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = self.list[indexPath.row];
        }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction *cert = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSString *name = alertController.textFields[0].text;
            BOOL p = [self isNameEmpty:name];
            if (p) {
                UIAlertController *bc = [UIAlertController alertControllerWithTitle:@"姓名不能为空" message:nil preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *cer = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
                [bc addAction:cer];
                [self presentViewController:bc animated:YES completion:nil];
            }else{
                [self.list2 replaceObjectAtIndex:0 withObject:name];
            }
            [self.table reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
            
        }];
        [alertController addAction:cancel];
        [alertController addAction:cert];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    if (indexPath.row == 1) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"\n\n\n\n" message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cert = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSString *text;
            if ([self.gender isEqualToNumber:@0]) {
                text = @"女";
            }else{
                text = @"男";
                self.gender = @0;
            }
            [self.list2 replaceObjectAtIndex:1 withObject:text];
            [self.table reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
            
        }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        [alertController addAction:cancel];
        [alertController addAction:cert];
        UIPickerView *pick = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.height*(265.0/568.0), self.view.frame.size.width*(100.0/320.0))];
        pick.dataSource = self;
        pick.delegate = self;
        [alertController.view addSubview:pick];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    if (indexPath.row == 2) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"\n\n\n\n\n\n\n\n" message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIDatePicker *datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.height*(265.0/568.0), self.view.frame.size.width*(150.0/320.0))];
        datePicker.datePickerMode = UIDatePickerModeDate;
        [datePicker setLocale:[NSLocale localeWithLocaleIdentifier:@"zh-CN"]];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM-dd"];
        datePicker.minimumDate = [formatter dateFromString:@"1910-01-01"];
        datePicker.maximumDate = [NSDate date];
        UIAlertAction *cert = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            NSString *stringDate = [formatter stringFromDate:[datePicker date]];
            [self.list2 replaceObjectAtIndex:2 withObject:stringDate];
            [self.table reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
            
        }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        [alertController addAction:cancel];
        [alertController addAction:cert];
        [alertController.view addSubview:datePicker];
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    if (indexPath.row == 3) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:self.list[indexPath.row] message:nil preferredStyle:UIAlertControllerStyleAlert];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = @"单位：cm";
            textField.keyboardType = UIKeyboardTypeNumberPad;
        }];
        UIAlertAction *cert = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSString *string =alertController.textFields[0].text;
            int height = [string intValue];
            if (height<=0 || height>=300) {
                UIAlertController *bc = [UIAlertController alertControllerWithTitle:@"身高不能小于0和超过3米" message:nil preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *cer = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
                [bc addAction:cer];
                [self presentViewController:bc animated:YES completion:nil];
            }else{
            [self.list2 replaceObjectAtIndex:3 withObject:alertController.textFields[0].text];
            }
            [self.table reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        [alertController addAction:cancel];
        [alertController addAction:cert];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    if (indexPath.row == 4) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:self.list[indexPath.row] message:nil preferredStyle:UIAlertControllerStyleAlert];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = @"单位：kg";
            textField.keyboardType = UIKeyboardTypeNumberPad;
        }];
        UIAlertAction *cert = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSString *string =alertController.textFields[0].text;
            int weight = [string intValue];
            if (weight<=0 || weight>=200) {
                UIAlertController *bc = [UIAlertController alertControllerWithTitle:@"体重不能小于0和超过200kg" message:nil preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *cer = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
                [bc addAction:cer];
                [self presentViewController:bc animated:YES completion:nil];
            }else{
            [self.list2 replaceObjectAtIndex:4 withObject:alertController.textFields[0].text];
            }
            [self.table reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        [alertController addAction:cancel];
        [alertController addAction:cert];
        [self presentViewController:alertController animated:YES completion:nil];
    }
}
@end
