//
//  operateListArray.m
//  界面设计
//
//  Created by liaozhi on 16/6/15.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import "operateListArray.h"
@interface operateListArray ()
@property (nonatomic,strong)NSFileManager *manege;
@property (nonatomic,strong)NSMutableArray<NSMutableArray *> *userList;
@property (nonatomic,strong)NSMutableArray<NSMutableArray *> *historyTest;
@end
static NSString *userName;
@implementation operateListArray
- (NSMutableArray *)userList {
    if (!_userList) {
        _userList = [[NSMutableArray alloc] init];
    }
    return _userList;
}
- (NSFileManager *)manege {
    if (!_manege) {
        _manege = [[NSFileManager alloc] init];
    }
    return _manege;
}
- (NSMutableArray *)historyTest {
    if (!_historyTest) {
        _historyTest = [[NSMutableArray alloc] init];
    }
    return _historyTest;
}
- (void)setUserName:(NSString *)name {
    userName = name;
}
- (NSString *)getUserName {
    return userName;
}
#pragma -mark 用户信息文件的操作
//路径
- (NSString *)path {
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/userList.xml"];
    return path;
}
//如果没有文件就创建文件
- (void)creatFile {
    if (![self.manege fileExistsAtPath:[self path]]) {
    [self.manege createFileAtPath:[self path] contents:nil attributes:nil];
    }
}
//获取文件里的全部数据
- (NSMutableArray *)readAllList {
    self.userList = [NSMutableArray arrayWithContentsOfFile:[self path]];
    return self.userList;
}
//添加用户数据
- (void)addUseInfo:(NSMutableArray *)userInfo {
    self.userList= [self readAllList];
    [self.userList addObject:userInfo];
    [self.userList writeToFile:[self path] atomically:YES];
}
//新用户数据与老的进行比较，判断是否重复,重复就覆盖
- (BOOL)compareUserInfo:(NSMutableArray *)userInfo {
    NSString *name = userInfo[0];
    __block BOOL p = false;
    self.userList = [self readAllList];
    __block NSUInteger i;
    [self.userList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([name isEqualToString:obj[0]]) {
            i = idx;
            p = YES;
            *stop = YES;
        }
    }];
    if (p == YES) {
        [self.userList replaceObjectAtIndex:i withObject:userInfo];
        [self.userList writeToFile:[self path] atomically:YES];
    }
    return p;
}
//删除用户数据
- (void)deleteUserInfo:(NSMutableArray *)userInfo {
    NSString *name = userInfo[0];
    __block NSUInteger p;
    self.userList = [self readAllList];
    [self.userList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([name isEqualToString:obj[0]]) {
            p = idx;
            *stop = YES;
        }
    }];
    [self.userList removeObjectAtIndex:p];
    [self.userList writeToFile:[self path] atomically:YES];
}

#pragma -mark 历史记录文件的操作
//路径
- (NSString *)Hpath {
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/historyTest.xml"];
    return path;
}
//如果没有文件就创建文件
- (void)HcreatFile {
    if (![self.manege fileExistsAtPath:[self Hpath]]) {
        [self.manege createFileAtPath:[self Hpath] contents:nil attributes:nil];
    }
}
//获取文件里的全部数据
- (NSMutableArray *)HreadAllList {
    self.historyTest = [NSMutableArray arrayWithContentsOfFile:[self Hpath]];
    return self.historyTest;
}
//添加用户数据
- (void)HaddUseInfo:(NSMutableArray *)record {
    self.historyTest= [self HreadAllList];
    [self.historyTest addObject:record];
    [self.historyTest writeToFile:[self Hpath] atomically:YES];
}
//查询用户数据
- (NSMutableArray *)HselectUserInfo:(NSString *)userName {
    NSString *name = userName;
    __block NSUInteger p;
    self.historyTest = [self HreadAllList];
    [self.historyTest enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([name isEqualToString:obj[0]]) {
            p = idx;
            *stop = YES;
        }
    }];
    return self.historyTest[p];
}
//新用户数据与老的进行比较，判断是否重复,重复就覆盖
- (BOOL)HcompareUserInfo:(NSMutableArray *)record {
    NSString *name = record[0];
    __block BOOL p = false;
    self.historyTest = [self HreadAllList];
    __block NSUInteger i;
    [self.historyTest enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([name isEqualToString:obj[0]]) {
            i = idx;
            p = YES;
            *stop = YES;
        }
    }];
    if (p == YES) {
        [self.historyTest[i] addObject:record[1]];
        [self.historyTest writeToFile:[self Hpath] atomically:YES];
    }
    return p;
}
//删除某个用户全部数据
- (void)HdeleteUserAllInfo:(NSMutableArray *)record {
    NSString *name = record[0];
    __block NSUInteger p;
    self.historyTest = [self HreadAllList];
    if (self.historyTest.count != 0) {
    [self.historyTest enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([name isEqualToString:obj[0]]) {
            p = idx;
            *stop = YES;
        }
    }];
    [self.historyTest removeObjectAtIndex:p];
    [self.historyTest writeToFile:[self Hpath] atomically:YES];
    }
}
//删除某个用户某条记录
- (void)HdeleteUserOneInfo:(NSMutableArray *)record numberOfRow:(NSInteger)row {
    NSString *name = record[0];
    __block NSUInteger p;
    self.historyTest = [self HreadAllList];
    [self.historyTest enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([name isEqualToString:obj[0]]) {
            p = idx;
            *stop = YES;
        }
    }];
    if (self.historyTest[p].count >1) {
        [self.historyTest[p] removeObjectAtIndex:row];
        [self.historyTest writeToFile:[self Hpath] atomically:YES];
    }
}
@end
