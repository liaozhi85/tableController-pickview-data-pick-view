//
//  ViewController.m
//  界面设计
//
//  Created by liaozhi on 16/6/8.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import "ViewController.h"
#import "historyListController.h"
#import "userListController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (IBAction)nUser {
    userListController *one = [self.storyboard instantiateViewControllerWithIdentifier:@"userListController"];
    [self.navigationController pushViewController:one animated:YES];
}
- (IBAction)oldUser {
    historyListController *two = [self.storyboard instantiateViewControllerWithIdentifier:@"historyListController"];
    [self.navigationController pushViewController:two animated:YES];
}
@end
