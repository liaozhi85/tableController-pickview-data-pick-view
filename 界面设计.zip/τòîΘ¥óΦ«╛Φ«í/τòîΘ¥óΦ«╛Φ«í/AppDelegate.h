//
//  AppDelegate.h
//  界面设计
//
//  Created by liaozhi on 16/6/8.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

