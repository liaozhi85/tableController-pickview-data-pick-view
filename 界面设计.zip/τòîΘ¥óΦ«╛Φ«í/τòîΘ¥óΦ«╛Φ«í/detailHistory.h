//
//  detailHistory.h
//  界面设计
//
//  Created by liaozhi on 16/6/18.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detailHistory : UIViewController <UITableViewDelegate,UITableViewDataSource>

@end
