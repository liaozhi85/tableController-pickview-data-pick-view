//
//  oneController.h
//  界面设计
//
//  Created by liaozhi on 16/6/13.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface registerController : UIViewController <UITableViewDelegate,UITableViewDataSource,UIPickerViewDataSource,UIPickerViewDelegate>
@property (nonatomic,strong)IBOutlet UITableView *table;
@property (nonatomic,strong)NSMutableArray *list2;
@end
