//
//  main.m
//  界面设计
//
//  Created by liaozhi on 16/6/8.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
