//
//  detailHistory.m
//  界面设计
//
//  Created by liaozhi on 16/6/18.
//  Copyright © 2016年 廖智. All rights reserved.
//

#import "detailHistory.h"
#import "operateListArray.h"
@interface detailHistory ()
@property (nonatomic,strong)operateListArray *operate;
@property (nonatomic,strong)NSMutableArray *record;
@property (nonatomic,strong)IBOutlet UITableView *table;
@end
@implementation detailHistory
- (operateListArray *)operate {
    if (!_operate) {
        _operate = [[operateListArray alloc] init];
    }
    return _operate;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *name = [self.operate getUserName];
    self.record = [self.operate HselectUserInfo:name];
    self.table.delegate = self;
    self.table.dataSource = self;
    
}
#pragma mark -UITableViewDataSource的实现
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.record.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"记录";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    if (indexPath.row == 0) {
        NSString *text = [NSString stringWithFormat:@"%@的测量记录",self.record[indexPath.row]];
        cell.textLabel.text = text;
    }else{
        cell.textLabel.text = self.record[indexPath.row];
    }
    return cell;
//        cell.detailTextLabel.text = 测试的时间
    
    
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.operate HdeleteUserOneInfo:self.record numberOfRow:indexPath.row];
        [self.record removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @"删除";
}
#pragma mark -UITableViewDelegate的实现
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return UITableViewCellEditingStyleNone;
    }else{
        return UITableViewCellEditingStyleDelete;
    }
}
@end
